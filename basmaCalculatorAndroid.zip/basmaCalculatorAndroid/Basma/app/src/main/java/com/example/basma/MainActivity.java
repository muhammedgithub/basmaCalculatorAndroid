package com.example.basma;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private EditText no1;
    private  EditText no2;
    private Button sum;
    private TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        no1 = (EditText) findViewById(R.id.no1);
        no2 = (EditText) findViewById(R.id.no2);
        sum =(Button)  findViewById(R.id.sum);
        textView = (TextView) findViewById(R.id.textView);

    }

    public void btnSum(View View)
    {
        String val1=no1.getText().toString();
        String val2=no2.getText().toString();
        double a=Double.parseDouble(val1);
        double b=Double.parseDouble(val2);
        double sum=a+b;
        textView.setText(String.valueOf(sum));

    }

    public void btnSub(View View)
    {
        String val1=no1.getText().toString();
        String val2=no2.getText().toString();
        double a=Double.parseDouble(val1);
        double b=Double.parseDouble(val2);
        double sum=a-b;
        textView.setText(String.valueOf(sum));

    }

    public void btnDiv(View View)
    {
        String val1=no1.getText().toString();
        String val2=no2.getText().toString();
        double a=Double.parseDouble(val1);
        double b=Double.parseDouble(val2);
        double sum=a/b;
        textView.setText(String.valueOf(sum));
    }

    public void btnMul(View View)
    {
        String val1=no1.getText().toString();
        String val2=no2.getText().toString();
        double a=Double.parseDouble(val1);
        double b=Double.parseDouble(val2);
        double sum=a*b;
        textView.setText(String.valueOf(sum));

    }

    public void btnAC (View View) {

        textView.setText("");
        no1.setText("");
        no2.setText("");
    }


    public void btnOFF (View View){
    System.exit(0);}

}